// =========================================================
// InspoAI Extension — Content Script v8.0
//
// Custom glassmorphic toolbar + Figma's capture engine.
// Now with Google SSO auth gate — users must sign in before
// using Capture for Figma.
// =========================================================

(function () {
    if (window.__inspoAiInjected) return;
    window.__inspoAiInjected = true;

    var captureActive = false;
    var highlightBox = null;
    var hoveredElement = null;
    var toolbarEl = null;

    // ── SVG Icons (inline, no emoji) ──────────────────────

    var ICON = {
        clipboard: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 11.5V3.5C3.5 2.95 3.95 2.5 4.5 2.5H9.5L12.5 5.5V11.5C12.5 12.05 12.05 12.5 11.5 12.5H4.5C3.95 12.5 3.5 12.05 3.5 11.5Z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/><path d="M9.5 2.5V5.5H12.5" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/><path d="M6 8H10M6 10H8.5" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/></svg>',
        screen: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="1.5" y="2.5" width="13" height="9" rx="1.5" stroke="currentColor" stroke-width="1.3"/><line x1="6" y1="13.5" x2="10" y2="13.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>',
        crosshair: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="5.5" stroke="currentColor" stroke-width="1.3"/><circle cx="8" cy="8" r="1.5" fill="currentColor"/><line x1="8" y1="1" x2="8" y2="3.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><line x1="8" y1="12.5" x2="8" y2="15" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><line x1="1" y1="8" x2="3.5" y2="8" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><line x1="12.5" y1="8" x2="15" y2="8" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>',
        close: '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><line x1="3.5" y1="3.5" x2="10.5" y2="10.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><line x1="10.5" y1="3.5" x2="3.5" y2="10.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
        check: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 8.5L6.5 11.5L12.5 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        spinner: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="6" stroke="currentColor" stroke-opacity="0.25" stroke-width="1.5"/><path d="M14 8A6 6 0 0 0 8 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
        warn: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 1.5L14.5 13.5H1.5L8 1.5Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/><line x1="8" y1="6" x2="8" y2="9.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><circle cx="8" cy="11.5" r="0.7" fill="currentColor"/></svg>',
        google: '<svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18A11.96 11.96 0 0 0 1 12c0 1.94.46 3.77 1.18 5.07l3.66-2.98z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>'
    };

    // ── InspoAI logo SVG ──────────────────────────────────

    var INSPO_LOGO = '<svg width="80" height="18" viewBox="0 0 134 31" fill="none" xmlns="http://www.w3.org/2000/svg">' +
        '<g clip-path="url(#clip_tb)">' +
        '<path d="M94.7036 9.41028C98.1257 9.41028 100.878 12.1628 100.878 15.5848C100.878 19.0069 98.1257 21.7594 94.7036 21.7594H79.0813C75.6592 21.7594 72.9067 19.0069 72.9067 15.5848C72.9067 12.1628 75.6592 9.41028 79.0813 9.41028H94.7036ZM94.7036 5.69067H79.0813C73.5763 5.69067 69.1871 10.1542 69.1871 15.5848C69.1871 21.0154 73.6507 25.479 79.0813 25.479H94.7036C100.209 25.479 104.598 21.0154 104.598 15.5848C104.598 10.1542 100.134 5.69067 94.7036 5.69067Z" fill="url(#grad_tb)"/>' +
        '<path d="M126.538 25.7035H122.616V23.5914C122.616 23.5914 122.54 23.6668 122.465 23.6668L122.39 23.7423C122.39 23.7423 122.39 23.7423 122.314 23.7423C120.579 24.9492 118.618 25.6281 116.506 25.6281C113.79 25.6281 111.376 24.6475 109.415 22.7617C107.454 20.8759 106.473 18.5375 106.473 15.7465C106.473 12.9555 107.454 10.6171 109.415 8.65589C111.376 6.69466 113.79 5.78947 116.506 5.78947C119.221 5.78947 121.56 6.77009 123.521 8.65589C125.482 10.6171 126.538 12.9555 126.538 15.7465V25.6281V25.7035ZM120.655 19.9707C121.786 18.8392 122.314 17.406 122.314 15.7465C122.314 14.087 121.786 12.7292 120.655 11.5223C119.523 10.3154 118.165 9.71193 116.506 9.71193C114.846 9.71193 113.413 10.3154 112.282 11.5223C111.15 12.7292 110.622 14.087 110.622 15.7465C110.622 17.406 111.226 18.7638 112.282 19.9707C113.413 21.1776 114.846 21.7056 116.506 21.7056C118.165 21.7056 119.523 21.1022 120.655 19.9707Z" fill="black"/>' +
        '<path d="M128.904 3.9058H133.716V7.50462H128.904V3.9058ZM133.716 25.6552V9.30403H128.904V25.577H133.716V25.6552Z" fill="black"/>' +
        '<path d="M23.8849 15.7455C23.8849 14.1614 23.2814 12.7282 22.15 11.5213C21.0185 10.3144 19.6607 9.7864 18.0012 9.7864C16.3417 9.7864 14.9839 10.3899 13.8524 11.5213C12.721 12.6528 12.1175 14.086 12.1175 15.7455V25.6271H7.96875V15.7455C7.96875 13.03 8.94936 10.6161 10.9106 8.65492C12.8718 6.69369 15.2856 5.78851 18.0012 5.78851C20.7167 5.78851 23.1306 6.76912 25.0918 8.65492C27.053 10.6161 28.0336 12.9545 28.0336 15.7455V25.6271H23.8849V15.7455Z" fill="black"/>' +
        '<path d="M39.5745 13.7839C40.4042 13.7839 41.1586 13.9348 41.9129 14.2365C42.6672 14.5382 43.2706 14.9908 43.7987 15.5188C44.3267 16.0469 44.7039 16.6503 45.081 17.4046C45.3827 18.0835 45.5336 18.9133 45.5336 19.6676C45.5336 20.4219 45.3827 21.2517 45.081 22.006C44.7793 22.6849 44.3267 23.3638 43.7987 23.8918C43.2706 24.4198 42.6672 24.8724 41.9129 25.1741C41.234 25.4759 40.4042 25.6267 39.5745 25.6267H30.1455V21.7043H39.6499C40.1779 21.7043 40.6305 21.4025 41.0077 21.0254C41.3848 20.6482 41.5357 20.1956 41.5357 19.6676C41.5357 19.1396 41.3094 18.6116 40.9323 18.2344C40.5551 17.8572 40.0271 17.6309 39.4991 17.6309H35.8029C34.9731 17.6309 34.2188 17.4046 33.5399 17.1029C32.7856 16.8012 32.1822 16.3486 31.6541 15.8206C31.1261 15.2925 30.7489 14.6891 30.4472 13.9348C30.1455 13.1805 29.9946 12.4261 29.9946 11.6718C29.9946 10.9175 30.1455 10.0877 30.4472 9.33342C30.7489 8.57911 31.2015 7.97565 31.7296 7.44763C32.2576 6.9196 32.861 6.46701 33.6154 6.16528C34.2942 5.86356 35.124 5.71269 35.9538 5.71269H41.4603V9.63515H35.9538C35.4257 9.63515 34.8977 9.86145 34.5205 10.2386C34.1434 10.6158 33.9171 11.0684 33.9171 11.6718C33.9171 12.2753 34.1434 12.7279 34.5205 13.105C34.8977 13.4822 35.3503 13.7085 35.9538 13.7085H39.5745V13.7839Z" fill="black"/>' +
        '<path d="M64.3917 8.73012C66.353 10.6914 67.3336 13.0297 67.3336 15.8207C67.3336 18.6117 66.353 20.9501 64.3917 22.8359C62.4305 24.7971 60.0167 25.7023 57.3011 25.7023C55.1136 25.7023 53.1524 25.0988 51.4174 23.8165V30.0774H47.2687V15.8207C47.2687 13.1052 48.2493 10.7668 50.2105 8.73012C52.1718 6.76889 54.5101 5.86371 57.3011 5.86371C60.0921 5.86371 62.4305 6.84432 64.3917 8.73012ZM61.5253 20.0449C62.6568 18.9134 63.1848 17.4802 63.1848 15.8207C63.1848 14.1612 62.6568 12.8034 61.5253 11.5965C60.3938 10.3896 59.0361 9.8616 57.3766 9.8616C55.7171 9.8616 54.3593 10.4651 53.2278 11.5965C52.0963 12.8034 51.5683 14.1612 51.5683 15.8207C51.5683 17.4802 52.0963 18.9134 53.2278 20.0449C54.3593 21.1764 55.7171 21.7798 57.3766 21.7798C59.0361 21.7798 60.3938 21.1764 61.5253 20.0449Z" fill="black"/>' +
        '<path d="M0.332031 3.90554H5.14385V7.50436H0.332031V3.90554ZM5.14385 25.655V9.30377H0.332031V25.5767H5.14385V25.655Z" fill="black"/>' +
        '</g>' +
        '<defs>' +
        '<linearGradient id="grad_tb" x1="104.598" y1="15.5848" x2="69.1871" y2="15.5848" gradientUnits="userSpaceOnUse">' +
        '<stop stop-color="#41F461"/><stop offset="0.5" stop-color="#008CFF"/><stop offset="0.856676" stop-color="#0D0D0D"/>' +
        '</linearGradient>' +
        '<clipPath id="clip_tb"><rect width="133.977" height="30.136" fill="white"/></clipPath>' +
        '</defs></svg>';

    // ═══════════════════════════════════════════════════════
    // Glassmorphic Toolbar
    // ═══════════════════════════════════════════════════════

    function showToolbar(mode) {
        // ── Remove ALL existing inspo toolbars (prevents stacking on multiple right-clicks) ──
        document.querySelectorAll('#__inspo_toolbar').forEach(function (el) { el.remove(); });
        removeToolbar(true);

        // Inject keyframes + pseudo-element styles once
        if (!document.getElementById('__inspo_tb_css')) {
            var css = document.createElement('style');
            css.id = '__inspo_tb_css';
            css.textContent = [
                '@keyframes __iSpin{to{transform:rotate(360deg)}}',
                '@keyframes __iFadeIn{from{opacity:0;transform:translateX(-50%) translateY(16px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}',
                '@keyframes __iShimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}',
                /* Gradient border glow — outer frame ::before */
                '#__inspo_toolbar::before{content:"";position:absolute;inset:-1px;border-radius:33px;padding:1px;background:linear-gradient(135deg,rgba(180,160,255,0.15),rgba(200,200,255,0.08),rgba(255,255,255,0.1));-webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);-webkit-mask-composite:xor;mask-composite:exclude;pointer-events:none;}',
                /* Button resets */
                '#__inspo_toolbar button{outline:none;border:none;background:transparent;cursor:pointer;transition:all .2s cubic-bezier(0.25,0.8,0.25,1);}',
                '#__inspo_toolbar button:active{transform:scale(0.96);}',
                /* Primary chip — raised white */
                '#__inspo_toolbar .tb-chip{background:rgba(255,255,255,0.9)!important;border:1px solid rgba(0,0,0,0.05)!important;box-shadow:0 1px 3px rgba(0,0,0,0.05),0 0.5px 1px rgba(0,0,0,0.04)!important;}',
                '#__inspo_toolbar .tb-chip:hover{background:rgba(255,255,255,1)!important;box-shadow:0 2px 6px rgba(0,0,0,0.07),0 1px 2px rgba(0,0,0,0.04)!important;}',
                /* CTA — solid dark */
                '#__inspo_toolbar .tb-cta{background:#111!important;color:#fff!important;box-shadow:0 2px 8px rgba(0,0,0,0.18),0 1px 2px rgba(0,0,0,0.1)!important;}',
                '#__inspo_toolbar .tb-cta:hover{background:#222!important;box-shadow:0 4px 12px rgba(0,0,0,0.22),0 1px 3px rgba(0,0,0,0.1)!important;}',
                '#__inspo_toolbar .tb-cta span{opacity:1!important;color:#fff!important;}',
                /* Google sign-in button */
                '#__inspo_toolbar .tb-google{background:#fff!important;border:1px solid rgba(0,0,0,0.1)!important;box-shadow:0 2px 8px rgba(0,0,0,0.08),0 1px 2px rgba(0,0,0,0.04)!important;color:#3c4043!important;}',
                '#__inspo_toolbar .tb-google:hover{background:#f8f9fa!important;box-shadow:0 4px 12px rgba(0,0,0,0.12),0 1px 3px rgba(0,0,0,0.06)!important;}',
                /* Regular button hover */
                '#__inspo_toolbar .tb-ghost:hover{background:rgba(0,0,0,0.04)!important;}',
                /* Drag handle */
                '#__inspo_toolbar .tb-drag{cursor:grab;opacity:0.18;transition:opacity .2s;}',
                '#__inspo_toolbar .tb-drag:hover{opacity:0.35;}',
                '#__inspo_toolbar .tb-drag:active{cursor:grabbing;opacity:0.45;}',
            ].join('\n');
            document.head.appendChild(css);
        }

        /* ── Outer frame ── */
        toolbarEl = document.createElement('div');
        toolbarEl.id = '__inspo_toolbar';
        toolbarEl.setAttribute('data-h2d-ignore', 'true');
        toolbarEl.style.cssText = [
            'position:fixed',
            'bottom:28px',
            'left:50%',
            'transform:translateX(-50%)',
            'z-index:2147483647',
            'padding:10px',
            'border-radius:32px',
            'font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","SF Pro Display",system-ui,"Segoe UI",Roboto,sans-serif',
            'font-size:15px',
            'font-weight:500',
            'line-height:1',
            'color:#1a1a1a',
            'user-select:none',
            'background:rgba(240,240,240,0.6)',
            'backdrop-filter:blur(60px) saturate(1.5)',
            '-webkit-backdrop-filter:blur(60px) saturate(1.5)',
            'border:1px solid rgba(255,255,255,0.5)',
            'box-shadow:0 0 0 0.5px rgba(0,0,0,0.04), 0 8px 40px rgba(0,0,0,0.06), 0 2px 8px rgba(0,0,0,0.03)',
            'animation:__iFadeIn 0.3s cubic-bezier(0.22,1,0.36,1) forwards'
        ].join(';');

        /* ── Inner card ── */
        var innerCard = document.createElement('div');
        innerCard.style.cssText = [
            'display:flex',
            'align-items:center',
            'gap:4px',
            'padding:0 12px',
            'height:64px',
            'border-radius:26px',
            'background:rgba(255,255,255,0.92)',
            'box-shadow:inset 0 1px 0 rgba(255,255,255,0.9), 0 0.5px 0 rgba(0,0,0,0.03)',
        ].join(';');

        var html = '';

        // ── Drag handle ──
        html += '<div class="tb-drag" data-drag="true" style="display:flex;flex-direction:column;gap:3px;padding:0 8px 0 4px;height:44px;align-items:center;justify-content:center;">';
        html += '<div style="display:flex;gap:3px;"><div style="width:4px;height:4px;border-radius:50%;background:currentColor;"></div><div style="width:4px;height:4px;border-radius:50%;background:currentColor;"></div></div>';
        html += '<div style="display:flex;gap:3px;"><div style="width:4px;height:4px;border-radius:50%;background:currentColor;"></div><div style="width:4px;height:4px;border-radius:50%;background:currentColor;"></div></div>';
        html += '<div style="display:flex;gap:3px;"><div style="width:4px;height:4px;border-radius:50%;background:currentColor;"></div><div style="width:4px;height:4px;border-radius:50%;background:currentColor;"></div></div>';
        html += '</div>';

        // ── Logo column ──
        html += '<div style="display:flex;align-items:center;padding:0 16px 0 8px;border-right:1px solid rgba(0,0,0,0.05);margin-right:4px;height:40px;">';
        html += INSPO_LOGO;
        html += '</div>';

        // ═══════════════════════════════════════════════════
        // AUTH GATE MODE — Sign in with Google
        // ═══════════════════════════════════════════════════
        if (mode === 'auth') {
            html += '<div style="display:flex;align-items:center;gap:12px;padding:0 8px;">';
            html += '<span style="opacity:0.5;font-size:13px;font-weight:400;white-space:nowrap;">Sign in to capture</span>';
            html += '</div>';
            html += '<button data-act="google-signin" class="tb-google" style="display:inline-flex;align-items:center;gap:8px;height:44px;padding:0 20px;border-radius:14px;font:inherit;white-space:nowrap;font-weight:600;font-size:14px;">';
            html += '<span style="display:flex;flex-shrink:0;">' + ICON.google + '</span>';
            html += '<span>Sign in with Google</span>';
            html += '</button>';
            html += mkSep();
            html += mkClose();
        }

        // ═══════════════════════════════════════════════════
        // SIGNING IN MODE — Loading state
        // ═══════════════════════════════════════════════════
        else if (mode === 'signing-in') {
            html += '<div style="display:flex;align-items:center;gap:10px;padding:0 20px;height:44px;">';
            html += '<div style="color:#1a1a1a;opacity:0.4;animation:__iSpin 0.8s linear infinite;display:flex;">' + ICON.spinner + '</div>';
            html += '<span style="opacity:0.4;font-weight:500;">Signing in…</span>';
            html += '</div>';
        }

        // ═══════════════════════════════════════════════════
        // MAIN MODE — Capture tools (shown after auth)
        // ═══════════════════════════════════════════════════
        else if (mode === 'main') {
            html += mkBtn('copy', ICON.clipboard, 'Copy to clipboard', 'chip');
            html += mkBtn('screen', ICON.screen, 'Entire screen', 'ghost');
            html += mkBtn('select', ICON.crosshair, 'Select element', 'ghost');
            html += mkSep();
            // Auth avatar/sign-out slot
            html += '<div id="__inspo_auth_slot" style="display:flex;align-items:center;"></div>';
            html += mkClose();
        }

        else if (mode === 'capturing') {
            html += '<div style="display:flex;align-items:center;gap:10px;padding:0 20px;height:44px;">';
            html += '<div style="color:#1a1a1a;opacity:0.4;animation:__iSpin 0.8s linear infinite;display:flex;">' + ICON.spinner + '</div>';
            html += '<span style="opacity:0.4;font-weight:500;">Capturing…</span>';
            html += '</div>';
            html += mkBtn('cancel', ICON.close, 'Cancel', 'ghost');
        }

        else if (mode === 'selecting') {
            html += mkBtn('copy', ICON.clipboard, 'Copy to clipboard', 'chip');
            html += mkBtn('screen', ICON.screen, 'Entire screen', 'ghost');
            html += mkBtn('select', ICON.crosshair, 'Select element', 'cta');
            html += mkSep();
            html += mkBtn('cancel', ICON.close, 'Cancel', 'ghost');
        }

        else if (mode === 'success') {
            html += '<div style="display:flex;align-items:center;gap:10px;padding:0 20px;height:44px;">';
            html += '<span style="color:#16a34a;display:flex;">' + ICON.check + '</span>';
            html += '<span style="font-weight:500;">Copied — paste in Figma</span>';
            html += '</div>';
            html += mkClose();
        }

        else if (mode === 'error') {
            html += '<div style="display:flex;align-items:center;gap:10px;padding:0 20px;height:44px;">';
            html += '<span style="color:#dc2626;display:flex;">' + ICON.warn + '</span>';
            html += '<span style="color:#991b1b;font-weight:500;">Failed</span>';
            html += '</div>';
            html += mkBtn('copy', ICON.clipboard, 'Retry', 'chip');
            html += mkClose();
        }

        else if (mode === 'auth-error') {
            html += '<div style="display:flex;align-items:center;gap:10px;padding:0 12px;height:44px;">';
            html += '<span style="color:#dc2626;display:flex;">' + ICON.warn + '</span>';
            html += '<span style="color:#991b1b;font-weight:500;font-size:13px;">Sign-in failed</span>';
            html += '</div>';
            html += '<button data-act="google-signin" class="tb-chip" style="display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 14px;border-radius:12px;font:inherit;white-space:nowrap;font-size:13px;font-weight:600;color:#555;">';
            html += '<span>Retry</span>';
            html += '</button>';
            html += mkSep();
            html += mkClose();
        }
        // ═══════════════════════════════════════════════════
        // PLAN EXPIRED MODE — Trial ended or plan cancelled
        // ═══════════════════════════════════════════════════
        else if (mode === 'plan-expired') {
            html += '<div style="display:flex;align-items:center;gap:10px;padding:0 8px;height:44px;">';
            html += '<span style="color:#f59e0b;display:flex;">' + ICON.warn + '</span>';
            html += '<span style="font-size:13px;font-weight:500;color:#92400e;white-space:nowrap;">Trial ended</span>';
            html += '</div>';
            html += '<a href="https://app.inspoai.io/pricing" target="_blank" data-act="upgrade" class="tb-cta" style="display:inline-flex;align-items:center;gap:8px;height:44px;padding:0 20px;border-radius:14px;text-decoration:none;font:500 14px/-apple-system,BlinkMacSystemFont,system-ui,sans-serif;white-space:nowrap;background:#111;color:#fff;">';
            html += '<span>Upgrade Plan</span>';
            html += '</a>';
            html += mkSep();
            // "I already upgraded" — click to re-verify plan via backend
            html += '<button data-act="reauth" style="display:inline-flex;align-items:center;gap:6px;height:44px;padding:0 14px;border-radius:14px;border:1.5px solid rgba(0,0,0,.12);background:transparent;font:500 13px/-apple-system,BlinkMacSystemFont,system-ui,sans-serif;color:#555;cursor:pointer;white-space:nowrap;">';
            html += '<span>I upgraded ↻</span>';
            html += '</button>';
            html += mkSep();
            html += mkClose();
        }



        innerCard.innerHTML = html;
        toolbarEl.appendChild(innerCard);
        document.body.appendChild(toolbarEl);

        // Wire events
        toolbarEl.querySelectorAll('[data-act]').forEach(function (b) {
            b.addEventListener('click', function (e) {
                e.preventDefault(); e.stopPropagation();
                var act = this.getAttribute('data-act');
                if (act === 'copy' || act === 'screen') doCaptureClipboard('body');
                else if (act === 'select') startSelectMode();
                else if (act === 'cancel') { stopSelectMode(); showToolbar('main'); }
                else if (act === 'close') removeToolbar();
                else if (act === 'google-signin') doGoogleSignIn();
                else if (act === 'retry') doCaptureClipboard('body');
                else if (act === 'reauth') {
                    // User says they upgraded — clear token and re-authenticate to pick up new plan
                    showToolbar('signing-in');
                    chrome.runtime.sendMessage({ type: 'INSPO_SIGN_OUT' }, function () {
                        doGoogleSignIn();
                    });
                }
            });
        });

        // ── Populate auth avatar (async) when in main mode ──
        if (mode === 'main') {
            var authSlot = document.getElementById('__inspo_auth_slot');
            if (authSlot) {
                chrome.runtime.sendMessage({ type: 'INSPO_GET_AUTH_STATE' }, function (state) {
                    if (chrome.runtime.lastError || !authSlot) return;
                    if (state && state.isSignedIn && state.user) {
                        var photoUrl = state.user.photoURL;
                        var initial = (state.user.displayName || state.user.email || '?')[0].toUpperCase();
                        authSlot.innerHTML = '<button id="__inspo_auth_btn" title="' + (state.user.email || '') + '" style="display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;border:2px solid rgba(0,0,0,0.06);background:#e8e8e8;cursor:pointer;overflow:hidden;padding:0;margin:0 4px;">'
                            + (photoUrl
                                ? '<img src="' + photoUrl + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" />'
                                : '<span style="font-size:14px;font-weight:700;color:#555;">' + initial + '</span>')
                            + '</button>';
                        var authBtn = document.getElementById('__inspo_auth_btn');
                        if (authBtn) {
                            authBtn.addEventListener('click', function (ev) {
                                ev.preventDefault(); ev.stopPropagation();
                                if (confirm('Signed in as ' + state.user.email + '.\n\nSign out?')) {
                                    chrome.runtime.sendMessage({ type: 'INSPO_SIGN_OUT' });
                                    showToolbar('auth');
                                }
                            });
                        }
                    }
                });
            }
        }

        // ── Drag logic ──
        var dragHandle = toolbarEl.querySelector('[data-drag]');
        if (dragHandle) {
            var isDragging = false;
            var startX, startY, startLeft, startBottom;

            dragHandle.addEventListener('mousedown', function (e) {
                e.preventDefault();
                e.stopPropagation();
                isDragging = true;
                startX = e.clientX;
                startY = e.clientY;
                var rect = toolbarEl.getBoundingClientRect();
                startLeft = rect.left + rect.width / 2;
                startBottom = window.innerHeight - rect.bottom;
                toolbarEl.style.animation = 'none';
                document.addEventListener('mousemove', onDragMove);
                document.addEventListener('mouseup', onDragEnd);
            });

            function onDragMove(e) {
                if (!isDragging) return;
                var dx = e.clientX - startX;
                var dy = e.clientY - startY;
                var newLeft = startLeft + dx;
                var newBottom = startBottom - dy;
                newBottom = Math.max(8, Math.min(window.innerHeight - 100, newBottom));
                newLeft = Math.max(100, Math.min(window.innerWidth - 100, newLeft));
                toolbarEl.style.left = newLeft + 'px';
                toolbarEl.style.bottom = newBottom + 'px';
                toolbarEl.style.transform = 'translateX(-50%)';
            }

            function onDragEnd() {
                isDragging = false;
                document.removeEventListener('mousemove', onDragMove);
                document.removeEventListener('mouseup', onDragEnd);
            }
        }
    }

    // ── Google Sign-In handler ────────────────────────────

    function doGoogleSignIn() {
        showToolbar('signing-in');
        chrome.runtime.sendMessage({ type: 'INSPO_SIGN_IN' }, function (result) {
            if (result && result.success) {
                // Auth successful — show the capture toolbar
                suppressFigmaToolbar();
                showToolbar('main');
            } else {
                showToolbar('auth-error');
            }
        });
    }

    function mkBtn(action, icon, label, variant) {
        var cls = variant ? ' class="tb-' + variant + '"' : '';
        var iconOpacity = variant === 'cta' ? '1' : '0.55';
        return '<button data-act="' + action + '"' + cls + ' style="display:inline-flex;align-items:center;gap:8px;height:44px;padding:0 18px;border-radius:14px;color:inherit;font:inherit;white-space:nowrap;">' +
            '<span style="display:flex;flex-shrink:0;opacity:' + iconOpacity + ';">' + icon + '</span>' +
            '<span>' + label + '</span></button>';
    }

    function mkClose() {
        return '<button data-act="close" class="tb-ghost" style="display:inline-flex;align-items:center;justify-content:center;width:42px;height:42px;border-radius:12px;color:#1a1a1a;opacity:0.25;">' + ICON.close + '</button>';
    }

    function mkSep() {
        return '<div style="width:1px;height:28px;background:rgba(0,0,0,0.05);margin:0 3px;flex-shrink:0;"></div>';
    }

    function removeToolbar(instant) {
        if (!toolbarEl) return;
        if (instant) { toolbarEl.remove(); toolbarEl = null; return; }
        toolbarEl.style.opacity = '0';
        toolbarEl.style.transform = 'translateX(-50%) translateY(10px)';
        toolbarEl.style.transition = 'all 0.25s ease';
        var el = toolbarEl;
        setTimeout(function () { el.remove(); }, 250);
        toolbarEl = null;
        if (window.location.hash.indexOf('figmacapture') !== -1) {
            history.replaceState(null, '', window.location.pathname + window.location.search);
        }
    }

    // ═══════════════════════════════════════════════════════
    // Figma capture engine integration
    // ═══════════════════════════════════════════════════════

    function ensureFigmaLoaded(cb) {
        // If figma capture is ACTUALLY ready in page context, skip loading
        if (document.querySelector('script[data-inspo-figma-capture]') &&
            typeof window.figma !== 'undefined' && window.figma && typeof window.figma.captureForDesign === 'function') {
            // Also ensure bridge is loaded
            if (document.querySelector('script[data-inspo-bridge]')) {
                cb(); return;
            }
        }

        // Remove stale script tags so we can reload fresh
        document.querySelectorAll('script[data-inspo-figma-capture], script[data-inspo-bridge]').forEach(function(s){ s.remove(); });

        var s1 = document.createElement('script');
        s1.src = chrome.runtime.getURL('figma-capture.js');
        s1.setAttribute('data-inspo-figma-capture', '1');
        s1.onload = function () {
            var s2 = document.createElement('script');
            s2.src = chrome.runtime.getURL('capture-bridge.js');
            s2.setAttribute('data-inspo-bridge', '1');
            s2.onload = function () { cb(); };
            s2.onerror = function () { showToolbar('error'); };
            document.head.appendChild(s2);
        };
        s1.onerror = function () { showToolbar('error'); };
        document.head.appendChild(s1);
    }

    function doCaptureClipboard(selector) {
        showToolbar('capturing');
        ensureFigmaLoaded(function () {
            window.dispatchEvent(new CustomEvent('__inspo_do_capture', {
                detail: { selector: selector || 'body' }
            }));
        });
    }

    window.addEventListener('__inspo_capture_done', function (e) {
        var d = e.detail || {};
        if (d.success) {
            showToolbar('success');
            // Track screenshot event
            try {
                chrome.runtime.sendMessage({
                    type: 'INSPO_TRACK_EVENT',
                    eventType: 'screenshot',
                    metadata: { url: window.location.href, title: document.title }
                });
            } catch (_) {}
            setTimeout(function () { if (toolbarEl) showToolbar('main'); }, 4000);
        } else {
            showToolbar('error');
        }
    });

    // ═══════════════════════════════════════════════════════
    // Element selection mode
    // ═══════════════════════════════════════════════════════

    function createHighlightBox() {
        if (highlightBox) return;
        highlightBox = document.createElement('div');
        highlightBox.id = '__inspo_highlight';
        highlightBox.setAttribute('data-h2d-ignore', 'true');
        highlightBox.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483646;border:2px solid rgba(0,140,255,0.7);background:rgba(0,140,255,0.06);border-radius:4px;transition:all 0.1s ease;display:none;box-shadow:0 0 0 3px rgba(0,140,255,0.12);';
        var lbl = document.createElement('div');
        lbl.id = '__inspo_label';
        lbl.style.cssText = 'position:absolute;top:-26px;left:-2px;background:rgba(0,140,255,0.88);backdrop-filter:blur(8px);color:#fff;font:600 11px/1 -apple-system,sans-serif;padding:3px 7px;border-radius:5px;white-space:nowrap;';
        highlightBox.appendChild(lbl);
        document.body.appendChild(highlightBox);
    }

    function removeHighlightBox() { if (highlightBox) { highlightBox.remove(); highlightBox = null; } }

    function updateHighlight(el) {
        if (!el || !highlightBox) return;
        var r = el.getBoundingClientRect();
        highlightBox.style.display = 'block';
        highlightBox.style.left = r.left + 'px'; highlightBox.style.top = r.top + 'px';
        highlightBox.style.width = r.width + 'px'; highlightBox.style.height = r.height + 'px';
        var l = highlightBox.querySelector('#__inspo_label');
        if (l) l.textContent = el.tagName.toLowerCase() + (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/)[0] : '') + ' – ' + Math.round(r.width) + '×' + Math.round(r.height);
    }

    function onMM(e) {
        if (!captureActive) return;
        if (e.target.closest('#__inspo_toolbar') || e.target.closest('#__inspo_highlight')) return;
        hoveredElement = e.target;
        updateHighlight(e.target);
    }

    function onMC(e) {
        if (!captureActive) return;
        if (e.target.closest('#__inspo_toolbar')) return;
        e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
        var el = hoveredElement || e.target;
        stopSelectMode();
        doCaptureClipboard(buildSelector(el));
    }

    function buildSelector(el) {
        if (!el) return 'body';
        if (el.id) return '#' + CSS.escape(el.id);
        var parts = [], n = el;
        while (n && n !== document.body && n !== document.documentElement) {
            var t = n.tagName.toLowerCase();
            if (n.id) { parts.unshift('#' + CSS.escape(n.id)); break; }
            var p = n.parentElement;
            if (p) { var s = Array.from(p.children).filter(function (c) { return c.tagName === n.tagName; }); if (s.length > 1) t += ':nth-of-type(' + (s.indexOf(n) + 1) + ')'; }
            parts.unshift(t); n = n.parentElement;
        }
        return parts.join(' > ') || 'body';
    }

    function onKD(e) {
        if (e.key === 'Escape') { if (captureActive) { stopSelectMode(); showToolbar('main'); } else if (toolbarEl) removeToolbar(); }
    }

    function startSelectMode() {
        if (captureActive) return;
        captureActive = true;
        createHighlightBox();
        document.addEventListener('mousemove', onMM, true);
        document.addEventListener('click', onMC, true);
        document.addEventListener('keydown', onKD, true);
        document.body.style.cursor = 'crosshair';
        showToolbar('selecting');
    }

    function stopSelectMode() {
        captureActive = false; hoveredElement = null; removeHighlightBox();
        document.removeEventListener('mousemove', onMM, true);
        document.removeEventListener('click', onMC, true);
        document.removeEventListener('keydown', onKD, true);
        document.body.style.cursor = '';
    }

    // ═══════════════════════════════════════════════════════
    // Entry point — message listener
    // ═══════════════════════════════════════════════════════

    chrome.runtime.onMessage.addListener(function (msg, sender, respond) {
        // Ping — used by service worker to check if this context is alive
        if (msg.type === 'INSPO_PING') {
            respond({ ok: true });
            return true;
        }

        // Normal capture start (user is authenticated — verified by service worker)
        if (msg.type === 'INSPO_START_CAPTURE') {
            suppressFigmaToolbar();
            showToolbar('main');
            respond({ ok: true });
            return true;
        }

        // Auth gate (user is NOT authenticated — show sign-in UI)
        if (msg.type === 'INSPO_SHOW_AUTH_GATE') {
            showToolbar('auth');
            respond({ ok: true });
            return true;
        }

        // Plan expired — trial ended or subscription cancelled
        if (msg.type === 'INSPO_PLAN_EXPIRED') {
            showToolbar('plan-expired');
            respond({ ok: true });
            return true;
        }

        // Re-authenticate (user upgraded plan on inspoai.io — refresh their token)
        if (msg.type === 'INSPO_REAUTH') {
            showToolbar('signing-in');
            chrome.runtime.sendMessage({ type: 'INSPO_SIGN_OUT' }, function () {
                chrome.runtime.sendMessage({ type: 'INSPO_SIGN_IN' }, function (result) {
                    if (result && result.success) {
                        suppressFigmaToolbar();
                        showToolbar('main');
                    } else {
                        showToolbar('auth-error');
                    }
                });
            });
            respond({ ok: true });
            return true;
        }

        // Auth state changed (re-render toolbar)
        if (msg.type === 'INSPO_AUTH_CHANGED') {
            if (toolbarEl) {
                if (msg.isSignedIn) {
                    showToolbar('main');
                } else {
                    showToolbar('auth');
                }
            }
            return true;
        }

        // Image capture for moodboard sidebar
        if (msg.type === 'INSPO_CAPTURE_IMAGE') {
            var imgUrl = msg.imageUrl;
            if (imgUrl) {
                try {
                    var img = document.querySelector('img[src="' + imgUrl + '"]');
                    var altText = img ? (img.alt || img.title || '') : '';
                    // Try to get base64 via canvas
                    if (img && img.complete && img.naturalWidth > 0) {
                        var canvas = document.createElement('canvas');
                        canvas.width = img.naturalWidth;
                        canvas.height = img.naturalHeight;
                        var ctx = canvas.getContext('2d');
                        try {
                            ctx.drawImage(img, 0, 0);
                            var base64 = canvas.toDataURL('image/png');
                            respond({ base64: base64, altText: altText });
                        } catch (e) {
                            // CORS — can't draw, fallback to URL
                            respond({ base64: null, altText: altText });
                        }
                    } else {
                        respond({ base64: null, altText: altText });
                    }
                } catch (e) {
                    respond({ base64: null, altText: '' });
                }
            } else {
                respond({ base64: null, altText: '' });
            }
            return true;
        }

        return true;
    });

    function suppressFigmaToolbar() {
        var obs = new MutationObserver(function () {
            var h = document.getElementById('__figma_capture_toolbar_host__');
            if (h) { h.style.cssText = 'display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;position:fixed!important;top:-9999px!important;'; }
        });
        obs.observe(document.body || document.documentElement, { childList: true, subtree: true });
        setTimeout(function () { obs.disconnect(); }, 30000);
    }

    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && toolbarEl && !captureActive) removeToolbar(); });
})();
