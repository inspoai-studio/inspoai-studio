// =========================================================
// InspoAI — Capture Bridge (runs in page's MAIN world)
//
// This file is injected as <script src="..."> to bypass CSP.
// Inline scripts are blocked by CSP, but extension-hosted
// script files bypass it.
//
// Communication:
//   Content script → Bridge: CustomEvent '__inspo_do_capture'
//   Bridge → Content script: CustomEvent '__inspo_capture_done'
// =========================================================

(function () {
    // Listen for capture requests from the content script
    window.addEventListener('__inspo_do_capture', function handler(e) {
        var selector = (e.detail && e.detail.selector) || 'body';

        if (!window.figma || !window.figma.captureForDesign) {
            window.dispatchEvent(new CustomEvent('__inspo_capture_done', {
                detail: { success: false, error: 'Figma capture not loaded' }
            }));
            return;
        }

        // Hook clipboard.write to detect when data is actually copied.
        // captureForDesign()'s promise only resolves when the user interacts
        // with Figma's own toolbar (which we hide), so we intercept the clipboard
        // write as the true success signal.
        var origWrite = navigator.clipboard.write.bind(navigator.clipboard);
        var origWriteText = navigator.clipboard.writeText.bind(navigator.clipboard);

        function restore() {
            navigator.clipboard.write = origWrite;
            navigator.clipboard.writeText = origWriteText;
        }

        function signalSuccess() {
            restore();
            window.dispatchEvent(new CustomEvent('__inspo_capture_done', {
                detail: { success: true }
            }));
        }

        function signalError(err) {
            restore();
            window.dispatchEvent(new CustomEvent('__inspo_capture_done', {
                detail: { success: false, error: String(err) }
            }));
        }

        navigator.clipboard.write = function (items) {
            return origWrite(items).then(signalSuccess).catch(function (e) {
                signalError(e);
                throw e;
            });
        };

        navigator.clipboard.writeText = function (text) {
            return origWriteText(text).then(signalSuccess).catch(function (e) {
                signalError(e);
                throw e;
            });
        };

        // Fire and forget — don't await the promise
        window.figma.captureForDesign({ selector: selector, verbose: false });

        // Safety timeout: 20 seconds
        setTimeout(function () {
            if (navigator.clipboard.write !== origWrite) {
                signalError('Capture timed out');
            }
        }, 20000);
    });
})();
