// =========================================================
// InspoAI Extension — Background Service Worker
//
// "Screenshot to Figma Editable" Chrome Extension
//
// Now with mandatory Google SSO (Firebase) auth gate.
// Users must sign in before using Capture for Figma.
// =========================================================

const INSPO_HOME_URL = 'https://www.inspoai.io/';
const CTX_SAVE_IMAGE = 'inspo-save-image';
const CTX_CAPTURE_FIGMA = 'inspo-capture-figma';

// ── InspoAI API Base URL ─────────────────────────────────
const INSPO_API_BASE = 'https://api.inspoai.io';

// ── Extension Version ────────────────────────────────────
const EXTENSION_VERSION = chrome.runtime.getManifest().version;

// ═══════════════════════════════════════════════════════════
// AUTH MODULE — Google SSO via Firebase
// ═══════════════════════════════════════════════════════════

/**
 * Initiates Google Sign-In, then exchanges for a Firebase ID token.
 * Flow: Google OAuth → Backend (create Firebase user + custom token) → Firebase REST API (ID token)
 */
async function handleGoogleSignIn() {
    try {
        // 1. Open the hosted Firebase auth page — user signs in with Google there.
        //    No GCP OAuth client setup needed. Works for unpublished extensions too.
        const { idToken, refreshToken } = await new Promise((resolve, reject) => {
            const AUTH_URL = `${INSPO_API_BASE}/extension-login`;
            let resolved = false;

            chrome.tabs.create({ url: AUTH_URL }, (tab) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }

                const tabId = tab.id;

                // Watch for the URL hash change that signals auth success
                const urlListener = (updatedTabId, changeInfo) => {
                    if (updatedTabId !== tabId || !changeInfo.url) return;
                    try {
                        const url = new URL(changeInfo.url);
                        const hash = new URLSearchParams(url.hash.slice(1));
                        const token = hash.get('token');
                        const refresh = hash.get('refresh');

                        if (token) {
                            resolved = true;
                            chrome.tabs.onUpdated.removeListener(urlListener);
                            chrome.tabs.onRemoved.removeListener(closeListener);
                            chrome.tabs.remove(tabId);
                            resolve({ idToken: token, refreshToken: refresh || null });
                        }
                    } catch (e) { /* ignore parse errors */ }
                };

                // If user manually closes the tab, cancel auth
                const closeListener = (removedTabId) => {
                    if (removedTabId === tabId && !resolved) {
                        chrome.tabs.onUpdated.removeListener(urlListener);
                        chrome.tabs.onRemoved.removeListener(closeListener);
                        reject(new Error('Sign-in cancelled'));
                    }
                };

                chrome.tabs.onUpdated.addListener(urlListener);
                chrome.tabs.onRemoved.addListener(closeListener);
            });
        });

        if (!idToken) {
            throw new Error('No token received from sign-in page');
        }

        // 2. Send Firebase ID token to backend → MongoDB upsert, returns user data
        const backendRes = await fetch(`${INSPO_API_BASE}/api/extension/auth`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ idToken, version: EXTENSION_VERSION })
        });

        if (!backendRes.ok) {
            const err = await backendRes.json().catch(() => ({}));
            throw new Error(err.error || 'Authentication failed');
        }

        const { firebaseApiKey, user } = await backendRes.json();

        // 3. Store Firebase auth state — we already have idToken + refreshToken
        //    from the hosted auth page, no custom token exchange needed.
        await chrome.storage.local.set({
            inspoAuthToken: idToken,
            inspoRefreshToken: refreshToken,
            inspoFirebaseApiKey: firebaseApiKey,
            inspoUser: user,
            inspoAuthTimestamp: Date.now()
        });

        console.log(`[InspoAI] Signed in via Firebase as ${user.email}`);

        // Notify all content scripts about auth change
        const tabs = await chrome.tabs.query({});
        for (const tab of tabs) {
            if (tab.id) {
                chrome.tabs.sendMessage(tab.id, {
                    type: 'INSPO_AUTH_CHANGED',
                    user: user,
                    isSignedIn: true
                }).catch(() => {});
            }
        }

        return { success: true, user };
    } catch (error) {
        console.error('[InspoAI] Sign-in error:', error.message);
        return { success: false, error: error.message };
    }
}

/**
 * Signs out — clears all Firebase auth state.
 */
async function handleSignOut() {
    try {
        await chrome.storage.local.remove([
            'inspoAuthToken', 'inspoRefreshToken', 'inspoFirebaseApiKey',
            'inspoUser', 'inspoAuthTimestamp'
        ]);

        // Notify all content scripts
        const tabs = await chrome.tabs.query({});
        for (const tab of tabs) {
            if (tab.id) {
                chrome.tabs.sendMessage(tab.id, {
                    type: 'INSPO_AUTH_CHANGED',
                    user: null,
                    isSignedIn: false
                }).catch(() => {});
            }
        }

        console.log('[InspoAI] Signed out');
        return { success: true };
    } catch (error) {
        console.error('[InspoAI] Sign-out error:', error.message);
        return { success: false, error: error.message };
    }
}

/**
 * Refresh the Firebase ID token using the refresh token.
 * Firebase ID tokens expire after 1 hour.
 */
async function refreshFirebaseToken() {
    try {
        const { inspoRefreshToken, inspoFirebaseApiKey } = await chrome.storage.local.get([
            'inspoRefreshToken', 'inspoFirebaseApiKey'
        ]);
        if (!inspoRefreshToken || !inspoFirebaseApiKey) return null;

        const res = await fetch(
            `https://securetoken.googleapis.com/v1/token?key=${inspoFirebaseApiKey}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `grant_type=refresh_token&refresh_token=${inspoRefreshToken}`
            }
        );

        if (!res.ok) return null;

        const data = await res.json();
        const newIdToken = data.id_token;
        const newRefreshToken = data.refresh_token;

        await chrome.storage.local.set({
            inspoAuthToken: newIdToken,
            inspoRefreshToken: newRefreshToken,
            inspoAuthTimestamp: Date.now()
        });

        console.log('[InspoAI] Firebase token refreshed');
        return newIdToken;
    } catch (error) {
        console.warn('[InspoAI] Token refresh failed:', error.message);
        return null;
    }
}

/**
 * Get a valid Firebase ID token, refreshing if needed.
 */
async function getValidToken() {
    const { inspoAuthToken, inspoAuthTimestamp } = await chrome.storage.local.get([
        'inspoAuthToken', 'inspoAuthTimestamp'
    ]);
    if (!inspoAuthToken) return null;

    // Firebase ID tokens expire after 1 hour — refresh after 55 min
    const tokenAge = Date.now() - (inspoAuthTimestamp || 0);
    if (tokenAge > 55 * 60 * 1000) {
        const refreshed = await refreshFirebaseToken();
        return refreshed || inspoAuthToken;
    }
    return inspoAuthToken;
}

/**
 * Get current auth state from storage.
 */
async function getAuthState() {
    const { inspoAuthToken, inspoUser } = await chrome.storage.local.get([
        'inspoAuthToken', 'inspoUser'
    ]);
    return {
        isSignedIn: !!inspoAuthToken,
        user: inspoUser || null,
        token: inspoAuthToken || null
    };
}

/**
 * Track an event (screenshot, capture_figma, etc.)
 */
async function trackExtensionEvent(eventType, metadata = {}) {
    try {
        const token = await getValidToken();
        if (!token) return;

        const res = await fetch(`${INSPO_API_BASE}/api/extension/track`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ eventType, metadata })
        });

        if (!res.ok) {
            console.warn('[InspoAI] Event track failed:', res.status);
        }
    } catch (error) {
        console.warn('[InspoAI] Event track error:', error.message);
    }
}

// ═══════════════════════════════════════════════════════════
// INSTALL / CONTEXT MENUS
// ═══════════════════════════════════════════════════════════

chrome.runtime.onInstalled.addListener((details) => {
    chrome.contextMenus.create({
        id: CTX_SAVE_IMAGE,
        title: "Save to InspoAI's Moodboard",
        contexts: ['image']
    });

    chrome.contextMenus.create({
        id: CTX_CAPTURE_FIGMA,
        title: '✨ Capture for Figma',
        contexts: ['page', 'frame']
    });

    if (details.reason === 'install') {
        chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
            if (tab?.id) chrome.tabs.update(tab.id, { url: INSPO_HOME_URL });
        });
    }

    console.log('[InspoAI] Extension installed.');
});

// ── Side Panel ───────────────────────────────────────────
chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch(console.error);

// ── Context Menu Clicks (with auth gate) ─────────────────
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (!tab?.id) return;

    if (info.menuItemId === CTX_SAVE_IMAGE) {
        const imageUrl = info.srcUrl || '';
        const pageUrl = info.pageUrl || tab.url || '';
        const pageTitle = tab.title || '';
        const domain = tab.url ? new URL(tab.url).hostname : '';

        await chrome.sidePanel.open({ tabId: tab.id });

        chrome.tabs.sendMessage(tab.id, {
            type: 'INSPO_CAPTURE_IMAGE',
            imageUrl,
        }, (response) => {
            const msg = {
                type: 'INSPO_ADD_IMAGE',
                payload: {
                    imageUrl,
                    base64: response?.base64 || null,
                    altText: response?.altText || '',
                    pageUrl, pageTitle, domain,
                },
            };
            const retry = (n) => {
                chrome.runtime.sendMessage(msg).catch(() => {
                    if (n > 0) setTimeout(() => retry(n - 1), 500);
                });
            };
            setTimeout(() => retry(3), 500);
        });
        return;
    }

    if (info.menuItemId === CTX_CAPTURE_FIGMA) {

        // ── PING: try the existing content script first ──
        // If it responds, context is alive — no need to re-inject
        chrome.tabs.sendMessage(tab.id, { type: 'INSPO_PING' }, async (pingResp) => {
            const alive = !chrome.runtime.lastError && pingResp?.ok;

            if (!alive) {
                // Context is dead (extension reloaded) — inject fresh
                try {
                    await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => { delete window.__inspoAiInjected; }
                    });
                    await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        files: ['content/content.js']
                    });
                    await new Promise(r => setTimeout(r, 200));
                } catch (e) { /* chrome:// pages won't allow this */ }
            }

            // ── Check auth + plan status ──
            const authState = await getAuthState();

            if (!authState.isSignedIn) {
                chrome.tabs.sendMessage(tab.id, { type: 'INSPO_SHOW_AUTH_GATE' }, () => { chrome.runtime.lastError; });
                return;
            }

            // Verify plan with backend (catches expired trials)
            try {
                const token = await getValidToken();
                const res = await fetch(`${INSPO_API_BASE}/api/extension/auth`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ idToken: token, version: EXTENSION_VERSION })
                });

                if (res.status === 403 || res.status === 402) {
                    // Plan expired or trial ended
                    chrome.tabs.sendMessage(tab.id, { type: 'INSPO_PLAN_EXPIRED' }, () => { chrome.runtime.lastError; });
                    return;
                }
            } catch (e) {
                // Network error — proceed anyway (offline grace)
            }

            // ── User is signed in with valid plan → start capture ──
            chrome.tabs.sendMessage(tab.id, { type: 'INSPO_START_CAPTURE' }, () => { chrome.runtime.lastError; });
        });

        return;
    }





});

// ── Keyboard Shortcut (with auth gate) ───────────────────
chrome.commands?.onCommand?.addListener(async (command) => {
    if (command === 'start-capture') {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) return;

        const authState = await getAuthState();
        if (authState.isSignedIn) {
            chrome.tabs.sendMessage(tab.id, { type: 'INSPO_START_CAPTURE' });
        } else {
            chrome.tabs.sendMessage(tab.id, { type: 'INSPO_SHOW_AUTH_GATE' });
        }
    }
});

// ═══════════════════════════════════════════════════════════
// MESSAGE HANDLERS
// ═══════════════════════════════════════════════════════════

// ── Helper: blob → base64 ────────────────────────────────
function blobToBase64(blob) {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = () => resolve(null);
        reader.readAsDataURL(blob);
    });
}

async function fetchImageBase64(url) {
    try {
        const resp = await fetch(url);
        if (!resp.ok) return null;
        const blob = await resp.blob();
        return blobToBase64(blob);
    } catch {
        return null;
    }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // ── Auth message handlers ────────────────────────────
    if (message.type === 'INSPO_SIGN_IN') {
        handleGoogleSignIn().then(result => sendResponse(result));
        return true;
    }
    if (message.type === 'INSPO_SIGN_OUT') {
        handleSignOut().then(result => sendResponse(result));
        return true;
    }
    if (message.type === 'INSPO_GET_AUTH_STATE') {
        getAuthState().then(state => sendResponse(state));
        return true;
    }

    // ── Tracking ─────────────────────────────────────────
    if (message.type === 'INSPO_TRACK_EVENT') {
        trackExtensionEvent(message.eventType, message.metadata || {});
        sendResponse({ ok: true });
        return true;
    }

    // ── Fetch image as base64 ────────────────────────────
    if (message.type === 'INSPO_FETCH_IMAGE') {
        fetchImageBase64(message.imageUrl).then((base64) => sendResponse({ base64 }));
        return true;
    }

    // ── Fetch SVG text ───────────────────────────────────
    if (message.type === 'INSPO_FETCH_SVG') {
        fetch(message.url)
            .then((r) => r.text())
            .then((svgText) => sendResponse({ svgText }))
            .catch(() => sendResponse({ svgText: null }));
        return true;
    }

    // ── Download file ────────────────────────────────────
    if (message.type === 'INSPO_DOWNLOAD_FILE') {
        try {
            const dataUrl = 'data:application/json;base64,' + btoa(unescape(encodeURIComponent(message.data)));
            chrome.downloads.download(
                { url: dataUrl, filename: message.filename || 'capture.inspo', saveAs: false },
                (downloadId) => {
                    if (chrome.runtime.lastError) {
                        console.error('[InspoAI] Download error:', chrome.runtime.lastError.message);
                        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
                    } else {
                        sendResponse({ ok: true, downloadId });
                    }
                }
            );
        } catch (err) {
            console.error('[InspoAI] Download error:', err);
            sendResponse({ ok: false, error: err.message });
        }
        return true;
    }

    // ── Capture screenshot ───────────────────────────────
    if (message.type === 'INSPO_CAPTURE_SCREENSHOT') {
        try {
            const windowId = sender.tab?.windowId;
            const dpr = message.devicePixelRatio || 1;
            const rect = message.rect || {};

            chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, (dataUrl) => {
                if (chrome.runtime.lastError || !dataUrl) {
                    console.warn('[InspoAI] Screenshot failed:', chrome.runtime.lastError?.message);
                    sendResponse({ dataUrl: null });
                    return;
                }
                // Track screenshot event
                trackExtensionEvent('screenshot', { tabUrl: sender.tab?.url });
                sendResponse({ dataUrl, rect, dpr });
            });
        } catch (err) {
            console.error('[InspoAI] Screenshot error:', err);
            sendResponse({ dataUrl: null });
        }
        return true;
    }

    // ── Get tab info ─────────────────────────────────────
    if (message.type === 'INSPO_GET_TAB_INFO') {
        chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
            sendResponse({
                pageUrl: tab?.url || '',
                pageTitle: tab?.title || '',
                domain: tab?.url ? new URL(tab.url).hostname : ''
            });
        });
        return true;
    }

    // ── Start capture (forwarded to content script) ──────
    if (message.type === 'INSPO_START_CAPTURE') {
        const tabId = sender.tab?.id;
        if (tabId) {
            chrome.tabs.sendMessage(tabId, { type: 'INSPO_START_CAPTURE' }, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn('[InspoAI] Could not start capture:', chrome.runtime.lastError.message);
                }
            });
            trackExtensionEvent('capture_figma', { tabUrl: sender.tab?.url });
            sendResponse({ ok: true });
        }
        return true;
    }
});
