// Extension Tracking Module — sends events to InspoAI backend
// Now uses Firebase ID tokens from Google SSO auth.

const API_BASE = 'https://api.inspoai.io';

/**
 * Track an extension event (install, screenshot, capture_figma, sign_in).
 * Uses Firebase ID token from chrome.storage (set by Google SSO auth flow).
 */
export async function trackEvent(eventType, metadata = {}) {
    try {
        // Get Firebase auth token (set by Google SSO sign-in)
        const result = await chrome.storage.local.get(['inspoAuthToken']);
        const token = result?.inspoAuthToken;

        const headers = { 'Content-Type': 'application/json' };
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const response = await fetch(`${API_BASE}/api/extension/track`, {
            method: 'POST',
            headers,
            body: JSON.stringify({ eventType, metadata })
        });

        if (response.ok) {
            const data = await response.json();
            console.log(`[InspoAI Tracking] ✅ ${eventType} tracked`);
        } else {
            console.warn(`[InspoAI Tracking] ❌ ${eventType} failed:`, response.status);
        }
    } catch (err) {
        // Silently fail — tracking should never break the extension
        console.warn(`[InspoAI Tracking] Error tracking ${eventType}:`, err.message);
    }
}
