var _0xInspo = (function () {
    var _0xa1 = ['__inspo_do_capture', '__inspo_capture_done', 'selector', 'body', 'figma', 'captureForDesign', 'clipboard', 'write', 'writeText', 'addEventListener', 'dispatchEvent', 'detail'];
    var _0xb2 = function (i) { return _0xa1[i]; };
    return { _init: function () {
        var _0xc9 = 0x4e20, _0xd1 = null, _0xe3 = false;
        var _0xf4 = function (_0x1a) { return typeof _0x1a === 'undefined' ? _0xb2(3) : _0x1a; };
        window[_0xb2(9)](
            _0xb2(0),
            function _0x2b(_0x3c) {
                var _0x4d = (_0x3c[_0xb2(11)] && _0x3c[_0xb2(11)][_0xb2(2)]) || _0xb2(3);
                if (!window[_0xb2(4)] || !window[_0xb2(4)][_0xb2(5)]) {
                    window[_0xb2(10)](new CustomEvent(_0xb2(1), { detail: { success: !0x1, error: _0xa1[5] + ' not loaded' } }));
                    return;
                }
                var _0x5e = navigator[_0xb2(6)][_0xb2(7)].bind(navigator[_0xb2(6)]);
                var _0x6f = navigator[_0xb2(6)][_0xb2(8)].bind(navigator[_0xb2(6)]);
                var _0x70 = function () { navigator[_0xb2(6)][_0xb2(7)] = _0x5e; navigator[_0xb2(6)][_0xb2(8)] = _0x6f; };
                var _0x81 = function () { _0x70(); window[_0xb2(10)](new CustomEvent(_0xb2(1), { detail: { success: !0x0 } })); };
                var _0x92 = function (_0xa3) { _0x70(); window[_0xb2(10)](new CustomEvent(_0xb2(1), { detail: { success: !0x1, error: String(_0xa3) } })); };
                navigator[_0xb2(6)][_0xb2(7)] = function (_0xb4) { return _0x5e(_0xb4).then(_0x81).catch(function (_0xc5) { _0x92(_0xc5); throw _0xc5; }); };
                navigator[_0xb2(6)][_0xb2(8)] = function (_0xd6) { return _0x6f(_0xd6).then(_0x81).catch(function (_0xe7) { _0x92(_0xe7); throw _0xe7; }); };
                window[_0xb2(4)][_0xb2(5)]({ [_0xb2(2)]: _0x4d, verbose: !0x1 });
                var _0xf8 = 0x0, _0x19 = function () { return ++_0xf8; };
                setTimeout(function () { if (navigator[_0xb2(6)][_0xb2(7)] !== _0x5e) { _0x92('\x43\x61\x70\x74\x75\x72\x65\x20\x74\x69\x6d\x65\x64\x20\x6f\x75\x74'); } }, _0xc9);
            }
        );
    }};
})();
_0xInspo._init();
